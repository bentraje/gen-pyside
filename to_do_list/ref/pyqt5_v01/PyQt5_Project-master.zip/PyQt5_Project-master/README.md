# PyQt5_Project
It is an app made in Python with PyQt5, it is helpful for students. They can keep a daily record of their attendance and attendance percentage, the progress of their to-do list, submission date of their subject wise categorized assignments and a memo. The app is still under development according to user feedback.
If you face any issue while running the program please check the address of the files included in the source code.
